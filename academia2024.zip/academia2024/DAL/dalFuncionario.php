<?php
namespace DAL;
include 'D:\Xampp\htdocs\academia2024\DAL\conexao.php';
include 'D:\Xampp\htdocs\academia2024\MODEL\Funcionario.php';

class dalFuncionario{


    public function Select(){

        $con = Conexao::conectar(); 
        $sql = "select * from funcionario;";
        $result = $con->query($sql);
        $con= Conexao::desconectar();
        
        //return $lstFuncionario retorna como objeto trazendo os métodos juntos
        foreach ($result as $linha){
            
            $funcionario = new \MODEL\Funcionario();     
            $funcionario->setId($linha['id']); 
            $funcionario->setNome($linha['nome']);         
            $funcionario->setCargo($linha['cargo']);
            $funcionario->setSalario($linha['salario']);
    
            $lstFuncionario[] = $funcionario; 

        }
        return $lstFuncionario;
        
    }

    

    public function Insert(\MODEL\Funcionario $funcionario){
        $con = Conexao::conectar(); 
        $sql = "INSERT INTO funcionario (nome, cargo, salario) 
               VALUES  ('{$funcionario->getNome()}', '      {$funcionario->getCargo()}',
                '{$funcionario->getSalario()}');";
        $result = $con->query($sql); 
        $con = Conexao::desconectar();
        return $result; 
    }

    public function SelectID(int $id){

        $sql = "select * from funcionario where id=?;";
        $pdo = Conexao::conectar(); 
        $query = $pdo->prepare($sql);
        $query->execute (array($id));
        $linha = $query->fetch(\PDO::FETCH_ASSOC);
        Conexao::desconectar(); 

        $funcionario = new \MODEL\Funcionario(); 
        $funcionario->setId($linha['id']);
        $funcionario->setNome($linha['nome']); 
        $funcionario->setCargo($linha['cargo']); 
        $funcionario->setSalario($linha['salario']); 

        return $funcionario; 
    }
    
    public function Update(\MODEL\Funcionario $funcionario){
        $sql = "UPDATE funcionario SET nome=?, cargo=?, salario=? WHERE id=?";

        $con = Conexao::conectar(); 
        $query = $con->prepare($sql);
        $result = $query->execute(array($funcionario->getNome(), $funcionario->getCargo(),                                        $funcionario->getSalario(), $funcionario->getId()));
        $con = Conexao::desconectar();
        return  $result; 
    }

    public function Delete(int $id){
        $sql = "DELETE FROM funcionario where id=?";
        $con = Conexao::conectar(); 
        $query = $con->prepare($sql);
        $result = $query->execute(array($id));
        $con = Conexao::desconectar();
        return  $result; 
    }

}
?>

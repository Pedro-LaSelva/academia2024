<?php
namespace DAL;
include_once 'd:\Xampp\htdocs\academia2024\DAL\conexao.php';
include_once 'D:\Xampp\htdocs\academia2024\MODEL\cliente.php';

class dalCliente{


    public function Select(){
        $sql = "select * from cliente;";

        $con = Conexao::conectar(); 
        $result = $con->query($sql); 
        $con = Conexao::desconectar();


        foreach ($result as $linha){
            $cliente = new \MODEL\Cliente(); 
            $cliente->setId($linha['id']); 
            $cliente->setNome($linha['nome']);   
            $cliente->setValor($linha['valor']); 
            $cliente->setData($linha['data']);

            $lstCliente[] = $cliente; 
        }

        return $lstCliente; 
 
      }

    public function Insert(\MODEL\Cliente $cliente){
        $con = Conexao::conectar(); 
        $sql = "INSERT INTO cliente (nome, valor, data) 
               VALUES  ('{$cliente->getNome()}', '{$cliente->getValor()}',
                        '{$cliente->getData()}');";
        $result = $con->query($sql); 
        $con = Conexao::desconectar();
        return $result; 
    }

    public function SelectID(int $id){

        $sql = "select * from cliente where id=?;";
        $pdo = Conexao::conectar(); 
        $query = $pdo->prepare($sql);
        $query->execute (array($id));
        $linha = $query->fetch(\PDO::FETCH_ASSOC);
        Conexao::desconectar(); 

        $cliente = new \MODEL\Cliente(); 
        $cliente->setId($linha['id']);
        $cliente->setNome($linha['nome']); 
        $cliente->setValor($linha['valor']); 
        $cliente->setData($linha['data']); 

        return $cliente; 
    }
    
    public function Update(\MODEL\Cliente $cliente){
        $sql = "UPDATE cliente SET nome=?, valor=?, data=? WHERE id=?";

        $con = Conexao::conectar();  
        $query = $con->prepare($sql);
        $result = $query->execute(array($cliente->getNome(), $cliente->getValor(),$cliente->getData(), $cliente->getId()));
        $con = Conexao::desconectar();
        return  $result; 
    }

    public function Delete(int $id){

        $sql = "DELETE FROM cliente where id=?";
        $con = Conexao::conectar();
        $query = $con->prepare($sql);
        $result = $query->execute(array($id));
        $con = Conexao::desconectar();
        return  $result; 
    }

}
?>
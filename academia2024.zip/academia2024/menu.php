<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <style>
p {
  background-image: 'https://png.pngtree.com/thumb_back/fw800/background/20230527/pngtree-black-gym-with-heavy-weights-image_2687614.jpg';
  }
</style>

    <title></title>
</head>

<body>
<nav>
    <div class="nav-wrapper grey darken-3">
      <a href="#" class="brand-logo right">Gym Acad
        <img src="https://cdn-icons-png.flaticon.com/512/905/905486.png" width="60px" height="60px">
      </a>
      <ul id="nav-mobile" class="left hide-on-med-and-down">
        <li><a href="http://localhost/academia2024/view/cliente/lstcliente.php">Listar Clientes</a></li>
        <li><a href="http://localhost/academia2024/view/funcionario/lstfuncionario.php">Listar Funcionarios</a></li>
        <li><a href="\academia2024\index.html">Logout</a></li>
      </ul>
    </div>
  </nav>
 
</body>

</html>
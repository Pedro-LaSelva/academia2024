<?php
$pwd = 'Pedro2004';
echo "Pedro2004"." - ". md5($pwd);
echo "<br> <br>";

echo "Pedro La Selva". "-". md5("Pedro La Selva");

?>
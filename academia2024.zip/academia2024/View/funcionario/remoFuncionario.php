<?php
include_once 'D:\Xampp\htdocs\academia2024\BLL\bllFuncionario.php';
include_once 'D:\Xampp\htdocs\academia2024\DAL\dalFuncionario.php';
include_once 'D:\Xampp\htdocs\academia2024\MODEL\Funcionario.php';

$id = $_GET['id'];

$dal = new \DAL\dalFuncionario();

$dal->Delete($id);

header("location:lstFuncionario.php");

?>
<?php
include_once 'D:\Xampp\htdocs\academia2024\BLL\bllFuncionario.php';
include_once 'D:\Xampp\htdocs\academia2024\DAL\dalFuncionario.php';
include_once 'D:\Xampp\htdocs\academia2024\MODEL\Funcionario.php';

$funcionario = new \MODEL\Funcionario();

$funcionario->setId($_POST['txtID']);
$funcionario->setNome($_POST['txtNome']);
$funcionario->setCargo($_POST['txtCargo']);
$funcionario->setSalario($_POST['numSalario']);

$bll = new \BLL\bllFuncionario();

$bll->Update($funcionario);

header("location:lstFuncionario.php");


?>
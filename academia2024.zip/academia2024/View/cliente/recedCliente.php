<?php
include_once 'D:\Xampp\htdocs\academia2024\BLL\bllCliente.php';
include_once 'D:\Xampp\htdocs\academia2024\DAL\dalCliente.php';
include_once 'D:\Xampp\htdocs\academia2024\MODEL\cliente.php';

$cliente = new \MODEL\Cliente();

$cliente->setId($_POST['txtID']);
$cliente->setNome($_POST['txtNome']);
$cliente->setValor($_POST['numValor']);
$cliente->setData($_POST['dtData']);

$bll = new \BLL\bllCliente();

$bll->Update($cliente);

header("location:lstCliente.php");


?>
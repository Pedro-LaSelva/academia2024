<?php
include_once 'D:\Xampp\htdocs\academia2024\BLL\bllCliente.php';
include_once 'D:\Xampp\htdocs\academia2024\DAL\dalCliente.php';
include_once 'D:\Xampp\htdocs\academia2024\MODEL\cliente.php';

$id = $_GET['id'];

$dal = new \DAL\dalCliente();

$dal->Delete($id);

header("location:lstCliente.php");

?>
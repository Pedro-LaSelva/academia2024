<?php
include_once 'D:\Xampp\htdocs\academia2024\BLL\bllCliente.php';
include_once 'D:\Xampp\htdocs\academia2024\DAL\dalCliente.php';
include_once 'D:\Xampp\htdocs\academia2024\MODEL\cliente.php';


$cliente = new \MODEL\Cliente();

$cliente->setNome($_POST['txtNome']);
$cliente->setValor($_POST['numValor']);
$cliente->setData($_POST['dtData']);

echo "Nome: " . $cliente->getNome() ."</br>";

$dal = new \DAL\dalCliente(); 

$dal->Insert($cliente); 

header("location:lstCliente.php");

?>
